package com.z9turbo

// Placeholder for future storage-cleaning helpers that guide users to large files
// and app-specific storage screens. Keeping the app lean in v1.
object StorageHelper