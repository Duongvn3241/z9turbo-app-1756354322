#!/data/data/com.termux/files/usr/bin/bash
# Z9 Turbo - build_on_phone.sh
# Tested on Termux (Android 10+). This script installs Android SDK + build-tools
# and builds a debug APK you can install.
set -e

# -------- Config (change if you want) --------
export SDK_ROOT="$HOME/android-sdk"
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
BUILD_TOOLS_VER="34.0.0"
PLATFORM_VER="android-34"
CMDLINE_TOOLS_VER="11076708_latest"   # from Google
PROJECT_DIR="$HOME/Z9Turbo"
GRADLE_USER_HOME="$HOME/.gradle"
# --------------------------------------------

echo "[1/7] Installing Termux packages..."
pkg update -y
pkg install -y openjdk-17 gradle zip unzip wget git

mkdir -p "$SDK_ROOT/cmdline-tools" "$PROJECT_DIR"

echo "[2/7] Unpacking project to $PROJECT_DIR ..."
# If running inside the project folder, skip copy. Otherwise copy from current dir/zip.
if [ -f "./settings.gradle.kts" ] && [ -f "./app/build.gradle.kts" ]; then
  rsync -a ./ "$PROJECT_DIR"/ || cp -r ./ "$PROJECT_DIR"/
elif [ -f "./Z9Turbo.zip" ]; then
  unzip -o "./Z9Turbo.zip" -d "$PROJECT_DIR"
else
  echo "Please place this script next to project files or Z9Turbo.zip, or run it from inside the project root."
  exit 1
fi

cd "$SDK_ROOT"

echo "[3/7] Downloading Android cmdline-tools..."
URL="https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_TOOLS_VER}.zip"
if [ ! -f "commandlinetools.zip" ]; then
  wget -O commandlinetools.zip "$URL"
fi
rm -rf cmdline-tools/latest || true
unzip -o commandlinetools.zip -d cmdline-tools-tmp
mkdir -p cmdline-tools/latest
mv -f cmdline-tools-tmp/cmdline-tools/* cmdline-tools/latest/ 2>/dev/null || true
rm -rf cmdline-tools-tmp

export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"
yes | sdkmanager --licenses >/dev/null

echo "[4/7] Installing SDK packages..."
sdkmanager "platform-tools" "platforms;${PLATFORM_VER}" "build-tools;${BUILD_TOOLS_VER}"

echo "[5/7] Environment check:"
java -version
gradle -v
sdkmanager --list | head -n 30 || true

echo "[6/7] Building debug APK..."
cd "$PROJECT_DIR"
# Workaround for low-RAM phones: set Gradle memory lower
mkdir -p "$GRADLE_USER_HOME"
echo "org.gradle.jvmargs=-Xmx1024m -Dfile.encoding=UTF-8" > "$GRADLE_USER_HOME/gradle.properties"

gradle assembleDebug --no-daemon --warning-mode all

APK_PATH=$(find "$PROJECT_DIR/app/build/outputs/apk/debug" -name "*-debug.apk" | head -n 1)
if [ -z "$APK_PATH" ]; then
  echo "Build failed: no APK found."
  exit 1
fi

echo "[7/7] APK ready: $APK_PATH"
echo
echo "Install via ADB (if you have a PC): adb install -r \"$APK_PATH\""
echo "Or share the APK from Termux: long-press -> Share, or move it to shared storage:"
echo "  termux-setup-storage    # grant storage"
echo "  cp \"$APK_PATH\" ~/storage/downloads/Z9Turbo-debug.apk"
echo "Then open it from Downloads and install (enable 'Install unknown apps')."
